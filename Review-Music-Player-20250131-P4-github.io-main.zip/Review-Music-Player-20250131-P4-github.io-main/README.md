# Review-Music-Player-20250131-P4-github.io
CS30 Lessons

** UNDER CONSTRUCTION **, beginning music player promotion:
- https://github.com/QEHS-Websites/Music-Player-Promotion
- https://github.com/QEHS-Websites/LearningHTML.github.io

- https://github.com/QEHS-Websites/Introductory-HTML/blob/main/HTML_Summary.txt

- https://github.com/QEHS-Websites/Grouped-Resources

- https://github.com/QEHS-Websites/Inner-HTML-JavaScript-Console.github.io

- https://github.com/QEHS-Websites/Using-CSS-github.io/blob/main/CSS_Intro-Summary.txt

# To Do List

### Client Side #1
- [x] Folder Structure
    - [X] Folder with ReadMe.txt: Lesson Prototyping
    - [x] Blank Intermediate-Advanced Processing Music Player Program
    - [x] Music:
        - Intermediate chooses 3 songs Weather App & 3 different songs for TicTacToe
        - Advanced chooses Pong Music
    - [x] Images related to music or theme, in Music Folder
    - [x] Old Music Player Code Folder, contains previous your music player
- [ ] Complete Case Study of Music Player Button
    - [ ] Materials Design
    - [ ] Functionality
    - [ ] DIVs & Ratios
    - [ ] Upload image to index.html
    - See: https://photos.google.com/share/AF1QipPh6eeCu35eJj9raP-4YN05qjB7rXPcqeEAmMRx0-JB-e1FPc8JdQQsf81uLtA2xQ
- [ ] TBA
- [ ] index.html: profile, images, and You Tube API Video changes
    - [ ] Purpose: able to imagine the app you will build
- DONE HTML #1

### Client Side #2
- [ ] TBA

---

See: https://github.com/QEHS-Websites/Music-Player-Promotion

Combine with this repository

---

